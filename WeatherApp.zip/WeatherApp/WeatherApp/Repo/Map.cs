﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.BAL;
using WeatherApp.Halper;
using WeatherApp.Interface;

namespace WeatherApp.Repo
{
    public static class Map
    {
        public static ResponseWeather WeatherDetails()
        {
            WeatherData _weather = new WeatherData();
            var result = _weather.DispalyWeather();
            return result;
        }
}
}
