﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Halper;
//using WeatherApp.Interface;

namespace WeatherApp.BAL
{
    public class WeatherData
    {
        public ResponseWeather DispalyWeather()
        {
            Console.WriteLine("Please Enter latitude and longitude value.");
            Console.WriteLine("Please Enter latitude value.");
            int lat = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter longitude value.");
            int log = Convert.ToInt32(Console.ReadLine());
            HttpWebRequest apiRequest = WebRequest.Create("https://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + log + "&appid=ae1c4977a943a50eaa7da25e6258d8b2") as HttpWebRequest;

            string apiResponse = "";
            using (HttpWebResponse response = apiRequest.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                apiResponse = reader.ReadToEnd();
            }

            ResponseWeather rootObject = JsonConvert.DeserializeObject<ResponseWeather>(apiResponse);
            Console.WriteLine("\n");
            Console.WriteLine("Display Result");
            Console.WriteLine("City: {0}", rootObject.name);
            Console.WriteLine("Country: {0}", rootObject.sys.country);
            Console.WriteLine("Wind:: {0}", rootObject.wind.speed);
            Console.WriteLine("Temperature: {0}", rootObject.main.temp);
            Console.WriteLine("Humidity: {0}", rootObject.main.humidity);

            return rootObject;
        }
    }
}
