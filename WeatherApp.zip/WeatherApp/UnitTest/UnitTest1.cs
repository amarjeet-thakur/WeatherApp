﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WeatherApp.Repo;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Wether_has_correct_data()
        {
            var result = Map.WeatherDetails();
            Assert.AreEqual("Shuzenji", result.name);
            Assert.AreEqual("JP", result.sys.country);
            Assert.AreEqual(0.89, result.wind.speed);
            Assert.AreEqual(280.55, result.main.temp);
            Assert.AreEqual(95, result.main.humidity);
        }
    }
}
